## Copyright 2023, [JOHN ALONSO VASQUEZ SALCEDO]

###### Please delete this line and the next one
###### APP TYPE can be a webpage/website, a web app, a software and so on

Permission is hereby granted, free of charge, to any person obtaining a copy of this [jovasal.github.io] and associated documentation files, to deal in the [jovasal.github.io] without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the [jovasal.github.io], and to permit persons to whom the [jovasal.github.io] is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the [jovasal.github.io].

THE [jovasal.github.io] IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE [jovasal.github.io] OR THE USE OR OTHER DEALINGS IN THE [jovasal.github.io].
